package com.alura.modelo;

public enum StatusTopico {
	
	NO_RESPONDIDO,
	NO_SOLUCIONADO,
	SOLUCIONADO,
	CERRADO;

}
